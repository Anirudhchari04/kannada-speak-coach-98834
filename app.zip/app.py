# Streamlit Voice Conversation App (Updated Gemini Config)
import streamlit as st
from gtts import gTTS
import os
import base64
import re
import time
import speech_recognition as sr
import google.generativeai as genai
from difflib import SequenceMatcher

# ==============================
# ✅ Gemini API Configuration (Updated)
# ==============================
genai.configure(api_key="AIzaSyDyJI7TfUgs39L0drjEHuiWb0oNnwcaymI")
model = genai.GenerativeModel("models/gemini-2.5-flash")

# ==============================
# 🎧 Helper Functions
# ==============================
def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        audio_html = f"""
            <audio autoplay="true" style="display:none;">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
        """
        st.markdown(audio_html, unsafe_allow_html=True)

def text_to_speech(text, filename="ai_response.mp3"):
    tts = gTTS(text)
    tts.save(filename)
    return filename

def recognize_speech_from_mic(prompt="🎙️ Speak now..."):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.info(prompt)
        recognizer.adjust_for_ambient_noise(source, duration=1)
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            return recognizer.recognize_google(audio)
        except Exception as e:
            st.warning("⚠️ Could not process speech. Try again.")
            return None

def generate_gemini_reply(topic, conversation):
    context = f"You are a friendly English speaking partner. Topic: {topic}. Simple, short answers.\n\n"
    convo_text = "".join([f"{m['role']}: {m['text']}\n" for m in conversation[-6:]])
    prompt = context + convo_text + "AI:"
    response = model.generate_content(prompt)
    return re.sub(r"\s+", " ", response.text.strip())

def calculate_pronunciation_accuracy(expected, spoken):
    if not spoken:
        return 0.0
    return round(SequenceMatcher(None, expected.lower(), spoken.lower()).ratio() * 100, 2)

def generate_final_feedback(conversation):
    scores = [m["score"] for m in conversation if m["role"] == "User"]
    avg = sum(scores)/len(scores) if scores else 0
    feedback = f"Your average pronunciation score: **{avg:.2f}%**\n"
    if avg >= 90:
        feedback += "🌟 Excellent clarity and fluency! Keep going!"
    elif avg >= 75:
        feedback += "👍 Good job! Work on a few pronunciations to sound even more natural."
    else:
        feedback += "💪 Keep practicing slowly and clearly to improve pronunciation."
    return feedback

# ==============================
# 🚀 Streamlit UI
# ==============================
st.set_page_config(page_title="AI Voice Conversation", page_icon="🎤")
st.title("🎤 AI English Conversation Practice (Voice Only)")

TOPICS = ["School Life", "Shopping", "Daily Life", "Family"]

if "topic" not in st.session_state:
    st.session_state.topic = None
if "conversation" not in st.session_state:
    st.session_state.conversation = []
if "turns" not in st.session_state:
    st.session_state.turns = 0
if "started" not in st.session_state:
    st.session_state.started = False

# Topic selection
if not st.session_state.started:
    topic = st.radio("Choose topic:", TOPICS, index=None)
    if topic and st.button("Start Conversation"):
        st.session_state.topic = topic
        st.session_state.started = True
        opening = generate_gemini_reply(topic, [])
        st.session_state.conversation = [{"role": "AI", "text": opening}]
        audio = text_to_speech(opening, "intro.mp3")
        autoplay_audio(audio)
        st.audio(audio)
        st.info("Now speak your reply 👇")

# Conversation mode
if st.session_state.started and st.session_state.turns < 5:
    topic = st.session_state.topic
    st.subheader(f"🗣️ Topic: {topic}")

    # Display chat
    for msg in st.session_state.conversation:
        if msg["role"] == "AI":
            st.chat_message("AI").write(msg["text"])
        else:
            st.chat_message("User").write(f"{msg['text']} (🎯 {msg['score']}%)")

    if st.button("🎤 Speak your reply"):
        spoken = recognize_speech_from_mic()
        if spoken:
            last_ai = next(m["text"] for m in reversed(st.session_state.conversation) if m["role"]=="AI")
            score = calculate_pronunciation_accuracy(last_ai, spoken)
            st.session_state.conversation.append({"role":"User", "text":spoken, "score":score})

            reply = generate_gemini_reply(topic, st.session_state.conversation)
            st.session_state.conversation.append({"role":"AI", "text":reply})
            st.session_state.turns += 1

            audio = text_to_speech(reply, "reply.mp3")
            autoplay_audio(audio)
            st.audio(audio)
            st.rerun()

# Final feedback
if st.session_state.turns >= 5:
    st.subheader("🎉 Session Complete!")
    st.markdown(generate_final_feedback(st.session_state.conversation))
    st.balloons()
    if st.button("🔄 Restart"):
        st.session_state.clear()
        st.rerun()